package cn.sdu.fd.service;

import cn.sdu.fd.pojo.Yonghu;

public interface YonghuService {
    //按照id查询
    Yonghu selectById(Long id);
    //修改信息
    void update(Yonghu yonghu);
}
