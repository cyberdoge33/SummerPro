package cn.sdu.fd.controller;


import cn.sdu.fd.pojo.Fangzhu;
import cn.sdu.fd.pojo.Yonghu;
import cn.sdu.fd.service.YonghuService;
import cn.sdu.fd.util.ServerResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;

@RestController
public class YonghuController {
    @Autowired
    private YonghuService yonghuService;
    //按id查询
    @GetMapping("/Yonghu/selectById")
    public ServerResult<Yonghu> selectById(Long id)
    {
        Yonghu yonghu = yonghuService.selectById(id);
        return ServerResult.ok(yonghu);
    }
    //修改信息
    @PostMapping(value="/Yonghu/update", consumes = "multipart/form-data")
    public ServerResult<Void> update(Yonghu yonghu, MultipartFile file){
        if (file != null) {
            File f = new File("E:/upload", file.getOriginalFilename());
            try {
                file.transferTo(f); // 保存图片
                yonghu.setTouxiang(f.getName());
            } catch (Exception e) {
            }
        }
        try {
            yonghuService.update(yonghu);
        } catch (RuntimeException e) {
            return ServerResult.error(500, e.getMessage());
        }
        return ServerResult.ok();
    }
}
