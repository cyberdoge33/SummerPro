package cn.sdu.fd.controller;


import cn.sdu.fd.pojo.Fangwuxinxi;
import cn.sdu.fd.pojo.Fangzhu;
import cn.sdu.fd.service.FangzhuService;
import cn.sdu.fd.util.ServerResult;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

@RestController
public class FangzhuController {
    @Autowired
    private FangzhuService fangzhuService;
    //查询所有
    @RequestMapping("/Fangzhu/selectAll")
    public ServerResult<List<Fangzhu>> selectAll()
    {
        List<Fangzhu> list = fangzhuService.selectAll();
        return ServerResult.ok(list);
    }
    //根据id查询，用于个人账户管理
    @GetMapping("/Fangzhu/selectById")
    public ServerResult<Fangzhu> selectById(Long id)
    {
        Fangzhu fangzhu = fangzhuService.selectById(id);
        return ServerResult.ok(fangzhu);
    }
    //添加账户，应用于注册
    @PostMapping("/Fangzhu/addFangzhu")
    public ServerResult<Void> addFangzhu(Fangzhu fangzhu)
    {
        fangzhuService.addFangzhu(fangzhu);
        return ServerResult.ok();
    }
    // 更新
    @PostMapping(value="/Fangzhu/update", consumes = "multipart/form-data")
    public ServerResult<Void> update(Fangzhu fangzhu, MultipartFile file){
        if (file != null) {
            File f = new File("E:/upload", file.getOriginalFilename());
            try {
                file.transferTo(f); // 保存图片
                fangzhu.setTouxiang(f.getName());
            } catch (Exception e) {
            }
        }
        try {
            fangzhuService.update(fangzhu);
        } catch (RuntimeException e) {
            return ServerResult.error(500, e.getMessage());
        }
        return ServerResult.ok();
    }

}
