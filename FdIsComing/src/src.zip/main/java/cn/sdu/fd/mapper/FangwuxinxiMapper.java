package cn.sdu.fd.mapper;


import cn.sdu.fd.pojo.Fangwuxinxi;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface FangwuxinxiMapper extends BaseMapper<Fangwuxinxi> {
}
