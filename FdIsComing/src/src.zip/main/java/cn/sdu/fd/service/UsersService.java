package cn.sdu.fd.service;

import cn.sdu.fd.pojo.Users;

import java.util.List;

public interface UsersService {

    //查询所有
    public List<Users> selectAll();
}
